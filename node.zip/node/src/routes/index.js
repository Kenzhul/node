const express = require('express');
const router = express.Router();

router.get('/',(rep,res) => {
    
    res.render('index.html', { title:'Bienvenido'});
});
router.get('/contact',(rep,res) => {
    
    res.render('contact.html', { title:'Contactos'});
});

module.exports=router;